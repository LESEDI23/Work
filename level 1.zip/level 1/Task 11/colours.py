
swimming = int(input("Enter time for completion of swimming?"))
cycling = int(input("Enter time for completion of cycling?"))
running = int(input("Enter time for completion of running?"))

Position = int(input(" Enter position number")
total_Q_time = int(input(swimming + cycling + running))


if total_Q_time >= 100 and position == 1:
    print(" Recieve Provincial Colours")
if total_Q_time >= 110 and position == 1 or 2:
    print(" Recieve Provincial Half Colours")

if total_Q_time >= 115:
    print("Recieve Provincial Scroll")
if total_Q_time >= 120:
    print("Recieve Provincial Certificate")
if total_Q_time > 120:
    print("No award")


    
    



