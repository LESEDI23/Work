print("\t\t\t\tTriangle of Numbers")

for i in range(1, 10):
    for j in range(i + 1):
        print(i * j, end = "\t")
    print("\n")
