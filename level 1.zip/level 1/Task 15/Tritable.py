num = int(input()) 

for x in num(1, 10, +1):
    for y in num(4, 19, +2):
      print(x)
    
     
        
         
         
     

    
     
    
