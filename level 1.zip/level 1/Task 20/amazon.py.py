calc = open("input.txt","w")

MIN: 1,2,3,5,6
MAX: 1,2,3,5,6
AVG: 1,2,3,5,6

calc.close()





calC = open("output.txt","w")

num = [1, 2, 3, 4, 5, 6]
total = int(1+2+3+4+5+6)
average = (total / 6)

print('MIN:' ,(scores), 'is' ,(min(num)))
print('MAX:' ,(scores), 'is' ,(max(num)))
print('AVG:' ,(scores), 'is' ,(average))



calC.close()
