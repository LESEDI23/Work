hero = "Super Man"
print(hero.replace("Super Man", "S^U^P^E^R^M^A^N"))

