Sentence = "The!quick!brown!fox!jumps!over!the!lazy!dog!"
print(Sentence.replace("!", " "))
print(Sentence.replace("!", " ").upper())
print(Sentence[-1:-44])


