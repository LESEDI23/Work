with open('DNA.txt', 'r+') as f:
 counter=1
 for i in f:
     currentLine = i.split(" ")
     name=currentLine[:2]
     name.insert(0,count);
     name.insert(0,"Name:");
     bithday=currentLine[3:];
     birthday.insert(0,"Birth date:");
     birthday.insert(1,count);
     count+=1;
     name=", ".join( repr(e) for e in name)
     birthday=", ".join repr(j) for j in birthday)
     name= name.replace(',', '')
     print(name)
     print(birthday)
