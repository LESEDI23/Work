question = int(input(" Enter price of the package ? ")))
print(question)
full_insurance = 50
limited_insurance = 25
gift = 15
no_gift = 0
priority = 100
standard_deliery = 20
freight = float(input(0.25)
air = float(input(0.36)

total_price = question

courier_choice = input(" Would you like to deliver your package through freight or air? Please choose 'freight' or 'air': ")
if courier_choice == "freight":
    delivery_distance = int(input("What is the total distance( in kilometres) that the parcel needs to trave?: ")
    courier_choice = float(delivery_distance)* float(freight)
                            
else:
     courier_choice == "air":
     delivery_distance = int(input("What is the total distance( in kilometres) that the parcel needs to trave?: ")                      
     courier_choice = float(delievery_distance) * float(air)

insurance_type = input(" We have two types of insurance, Please choose 'limited' or 'full' insurance: ")
if insurance_type == 'limited'
    insurance_type = limited_insurance
else:
    insurance_type == 'full':
    insurance_type = full_insurance

gift_type = input("Would you like to send this parcel as gift ? choose 'yes' or 'no': ")
if gift_type == 'yes'
    gift_type = gift
else:
    gift_type == 'no':
    gift_type = no_gift
deliery_type = input("Would you like to use our priorirty or standard delievery ? choose between 'priority' or 'standard': ")
if deliery_type == "priorty"
   deliery_type = priority
else:
    deliery_type == "standard"
    deliery_type = standard_deliery                         








                             







