age = int(input("Enter number:"))

if age > 18:
      print (" You are old enough!")
elif age > 16:
      print ("You are almost there!")
else:
      print ("You are just too young!")
