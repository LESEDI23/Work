
noDays = int(input("How many days did you work this month?"))
payPerDay = float(input("How much is your pay per day?"))
salary = noDays * payPerDay
print ("My salary for the month is R" + str(salary))
