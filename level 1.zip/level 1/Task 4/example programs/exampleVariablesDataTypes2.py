
# This is an example program.
# The purpose of this program is to demonstrate the different operations of different variables.


numOne = 10
numSquared = numOne * numOne 


# You can use a variable to create new variables as seen above.


print (numSquared)


nameFirst = "Tim"
nameSecond = "Adams"
nameFull = nameFirst + nameSecond 


# But don't forget a space between the two names, otherwise nameFull just stores "TimAdams".
# Adding a space in-between the names:


nameFull = nameFirst + " " + nameSecond 


print (nameFull)


numLong = 10
numDivide = 10/3


print (numDivide)

