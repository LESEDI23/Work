name = "Lesedi"
age = 23

houseNum = 2362
strName = "Spruitview Gardens"
print ( 'This is ' + name + "he is" + str(age) "he stays at + str(houseNum)  strName
