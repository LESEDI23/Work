num1 = 99.23
num2 = 23
num3 = 150
stringl = "100"
print (num1)
print(num2)
print(num3)
num1Int = int(num1)
num2float = float(num2)
num3str = str(num3)
stringlInt = int(stringl)
print(num1Int)
print(num2float)
print(num3str)
print(stringlInt)
