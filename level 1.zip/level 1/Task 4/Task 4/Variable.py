num = 6
print(num)

mySurname = "Moteka"
print(mySurname)

numFloat = 67.5
print(numFloat)

