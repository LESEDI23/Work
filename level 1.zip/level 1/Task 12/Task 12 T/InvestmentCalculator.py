import math

p = int(input(" Enter amount: "))
i = float(input(" Enter interest rate: "))
t = int(input(" Enter number of years of the investment: "))
simple_interest = p * (1 + i *t)
compound_interest = p * math.pow((1 + i ), t)


interest_type = input("Which interest type would you like? please chooses 'simple interest' or 'compound interest'?: ")
if interest_type == "simple interest":
   interest_type = simple_interest
else:
     interest_type == "compound interest"
     interest_type = compound_interest

total_interest = interest_type

print(total_interest)






                
        
    




