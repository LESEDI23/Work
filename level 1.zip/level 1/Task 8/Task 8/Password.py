counter = 0


length_of_password = False

contain_uppercase = False

contain_lowcase = False

contain_Num = False


question_1 = input("Is your password 6 or more chars ? ")
if question_1 == "yes":
    length_of_password = True
    counter += 1

question_2 = input("Does your password contain uppercases ?")
if question_2 == "yes":
    contain_uppercase = True
    counter += 1

question_3 = input("Does your password contain lowercases ?")
if question_3 == "No":
    contain_lowcase = False

question_4 = input("Does your password contain numbers ?")
if question_4 == "yes":
   contain_Num = True
   count += 1
    
