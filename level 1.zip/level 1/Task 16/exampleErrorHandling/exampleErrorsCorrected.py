name = "Tim"        
surname = " Jones"          
age = 21
  
fullMessage = name + surname +  " " + "is" + " "  + str(age) + " years old" 
print (fullMessage)   
