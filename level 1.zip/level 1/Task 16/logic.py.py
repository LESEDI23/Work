temp = int(input(" How warm is it today: "))

if temp < 30:
  print(" It's hot ! ")
else:
    print(" It's cold ! ")
