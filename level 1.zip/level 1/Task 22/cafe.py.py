from collections import Counter

menu=["coffee","cakes","doughnuts","smoothies"];

stock={
    'coffee': 4,
    'cakes': 5,
    'doughnuts': 10,
    'smoothies': 21,
}

price={
    'coffee': 8,
    'cakes': 10,
    'doughnuts': 25,
    'smoothies': 42,
}

menuSum == Counter(stock) + Counter(price)
print(menu)
    
