totalArr=[];

hotelNights=input("How many days will you stay in the hotel ? (enter a nummber and press 'Enter')");

def hotel(nights):
    cost=200;
    hotelTotal=cost*int(nights);
    totalArr.append(hotelTotal);
    print('Your hotel costs: ${}'.formmat(hotelTotal));

fly=input("Are you flying to London, Paris, New York, or Los Angeles? (Enter a number and press 'Enter')")
fly=fly.replace(" ", "").lower();
def flights(city):
    london=250;
    paris=300;
    newYork=400;
    losAngeles=350;

    if city=="london":
      totalArr.append(london);
      print('Your flight costs: ${}'.format(london));

    elif city=="paris":
      totalArr.append(paris);
      print('Your flight costs: ${}'.format(paris));

    elif city=="newYork":
       totalArr.append(newYork);
       print('Your flight costs: ${}'.format(newYork));

    elif city=="losAngeles":
        totalArr.append(losAngeles);
        print('Your flight costs: ${}'.format(losAngeles));
    else:
        print("That's not a validdestination");

carDays=input("how many days do you need to rent a car? (Enter a number and press 'Enter'")
def car(days):
    cost=20;
    carTotal=cost*int(days);
    totalArr.append(carTotal);
    print(' your car car rental costs: ${}'.format(carTotal));

def totalCost(a):
    total=sum(a);
    print('Your trip total costs: ${}'.format(total));

hotel(hotelNights);
flights(fly);
car(carDays);
totalCost(totalArr);
    
        
            
