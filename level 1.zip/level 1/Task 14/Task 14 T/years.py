year = int(input("What year do you want to start with?: "))
num_years = int(input("Enter number of years: ")) 

for year in range(year, year + num_years):
    if year %4 == 0:
        print(" It is a leap year")
    
else:

     print(" It is not a leap year")
    
   
 
    


    

 



    
    

    
          


          
      

    
