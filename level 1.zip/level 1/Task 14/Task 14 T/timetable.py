num = int(input("Enter number: "))

for i in range (1, 10):
    print(str(i) + "*" + str(num) + "=" + str(i*num))
          
      
