#This is an example Python program demonstrating if statements.

name = input("Enter your name: \n")

if len(name) == 0:
	print ("Your didn't enter anything.")

if len(name) > 10:
		print ("You've got a long name.")

print (name)

#Run this program. Change your input to get different outputs due to the if statements.



