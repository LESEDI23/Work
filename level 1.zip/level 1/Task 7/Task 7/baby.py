print("Which year were you born?")
year_born = int(input("enter year "))

print("Present year?")
present = int(input("enter year"))

age = present - year_born 
print(age)

if (age > 18):
    print("Congrats you are old enough")

1993-2019
