regForm = open('RegForm.txt', 'w')



for i in range(0,5):
    
    name = input("Enter student name: ")
    id = input("Enter student id: ")
    print(name + " " + id)   
    regForm.write(name + " " + id)



regForm.close()
