word =(" Hello World ")
word = word.replace("Hello World", "HeLlo WoRlD")
print(word)
