word = 'googl.com'
print(word.count('o'))
