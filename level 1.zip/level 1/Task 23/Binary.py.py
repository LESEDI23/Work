print("\nBinary: ")
import math

number = 30
print("Binary number is equals to : " + str(math.sqrt(30)) +".")

binary= '11001'
decimal = 0
for digit in binary :
    decimal = decimal*2 + int(digit)
    print(decimal)
