
f = open('DOB.txt', 'r')
names = 0
bd = 0

#print out name
print("Name\n")

#create a for loop to use for names
for name in f:
    names += 1

    #split into a array
    makeName=name.split()
    #print(makeName)
    
    #splice name from index 0 to 1
    nameSplice = makeName[0:2]
    #print(nameSplice)
    
    #join names together
    joinName = ' '.join(nameSplice)
    #print out names
    print(str(names) + ". " +joinName)

#open text file , we're only reading and structuring data so r suffices    
f = open('DOB.txt', 'r')

#print out date
print("\nDate\n")

#create for loop for dates
for date in f:
    bd += 1
    #split up into a array
    makeDate=date.split()
    #splice text from index 2 to 4
    dateSplice = makeDate[2:5]
    #join dates together
    joinDate = ' ' .join(dateSplice)
    #print out dates
    print(str(bd) + ". " + joinDate)
    

f.close()
