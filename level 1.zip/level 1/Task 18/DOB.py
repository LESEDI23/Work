f = open('DOB.txt', 'r')
names = 0
bd = 0


print("Name\n")


for name in f:
    names += 1

    
    makeName=name.split()
    
    
    
    nameSplice = makeName[0:2]
   
    joinName = ' '.join(nameSplice)
    
    print(str(names) + ". " +joinName)

   
f = open('DOB.txt', 'r')


print("\nDate\n")


for date in f:
    bd += 1
    
    makeDate=date.split()
    
    dateSplice = makeDate[2:5]
  
    joinDate = ' ' .join(dateSplice)
   
    print(str(bd) + ". " + joinDate)
    

f.close()
