print("name three of the products and their prices?")

product1 = float(input("Enter price "))
product2 = float(input("Enter price "))
product3 = float(input("Enter price "))

total_of_products = product1 + product2 + product3
print(total_of_products)

average_price_of_products = (product1 + product2 + product3) / 3
average_price_of_products = round(average_price_of_products,2)
print(average_price_of_products)

print("The Total of "  + str(product1)  + str(product2)  + str(product3) + " is R " + str(total_of_products))
