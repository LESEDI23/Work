print("Please enter three different integers?")
    
num1 = int(input("Enter a number ")) 
num2 = int(input("Enter a number "))
num3 = int(input("Enter a number "))

sum_of_nums = num1 + num2 + num3
print(sum_of_nums)

sum2 = num2 - num1

print(sum2)

sum3 = num3 * num1

print(sum3)

sum4 = (num1 + num2 + num3) / num3

print(sum4)


