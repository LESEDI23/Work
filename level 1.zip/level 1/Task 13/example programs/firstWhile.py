
start = 5
while start%2 != 0:
    print (start)
    start = start + 1
#loop will only execute once before condition is no longer true



