num = int(input("Enter number : "))

avg_counter = 0
total = 0

while num != -1:
    num = int(input("Enter number : "))
    total += num 
    avg_counter += 1

print(avg_counter)
        
