

i=10
while i < 14:
    print ("I can see infinity")
