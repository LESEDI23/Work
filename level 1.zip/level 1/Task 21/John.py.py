print("List")
stringList = ['Mark', 'Tim', 'John']
print("Tim,Mark,John")

names=True;
namesArr=[];

while names ==True:
    namesList = input("Enter names to add to the list. Enter 'John' to stop adding names to the list:...");

    namesList=namesList.lower();
    namesArr.append(namesList);

    if namesList == "John":
      namesArr.remove("John");
      namess=False;
      print(namesArr);

     



     


